<?php 
session_start();

unset($_SESSION['idmaster_pa_admin']);
?>
<script>
	window.location="http://172.30.1.38:8080/pa/admin/";
</script>