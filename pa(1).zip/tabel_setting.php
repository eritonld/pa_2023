<?php

$tahunperiode='2022';
$karyawan="karyawan_".$tahunperiode;
$transaksi_pa="transaksi_pa_q1_".$tahunperiode;//asli
$transaksi_pa_awal="transaksi_pa_awal_q1_".$tahunperiode;//awal
$transaksi_pa_edit1="transaksi_pa_edit1_q1_".$tahunperiode;//edit1
$transaksi_pa_edit2="transaksi_pa_edit2_q1_".$tahunperiode;//edit2
$transaksi_pa_detail="transaksi_pa_detail_q1_".$tahunperiode;
$tugas_managerial="tugas_managerial_q1_".$tahunperiode;
$quartal_periode=$tahunperiode;
$tabel_sp="sp_".$tahunperiode;
$karyawan_promosi = "karyawan_promosi_".$tahunperiode;

// if(isset($_POST['tahunproses']) || isset($_GET['tahunproses'])){
	
	// if(isset($_GET['tahunproses'])){
		// $tahunproses= $_GET['tahunproses'];
	// }else if(isset($_POST['tahunproses'])){
		// $tahunproses=$_POST['tahunproses'];
	// }
	
	// if($tahunproses=='2019' || $tahunproses=='') 
	// {
		// $tahunperiode='2019';
		// $karyawan="karyawan_".$tahunperiode;
		// $transaksi_pa="transaksi_pa_q1_".$tahunperiode;//asli
		// $transaksi_pa_awal="transaksi_pa_awal_q1_".$tahunperiode;//awal
		// $transaksi_pa_edit1="transaksi_pa_edit1_q1_".$tahunperiode;//edit1
		// $transaksi_pa_edit2="transaksi_pa_edit2_q1_".$tahunperiode;//edit2
		// $transaksi_pa_detail="transaksi_pa_detail_q1_".$tahunperiode;
		// $tugas_managerial="tugas_managerial_q1_".$tahunperiode;
		// $quartal_periode="Q1-2019";
		// $tabel_sp="sp_2019";
		// $karyawan_promosi = "karyawan_promosi_".$tahunperiode;
	// }
	// else if($tahunproses=='2020' || $tahunproses=='') 
	// {
		// $tahunperiode='2020';
		// $karyawan="karyawan_".$tahunperiode;
		// $transaksi_pa="transaksi_pa_q1_".$tahunperiode;//asli
		// $transaksi_pa_awal="transaksi_pa_awal_q1_".$tahunperiode;//awal
		// $transaksi_pa_edit1="transaksi_pa_edit1_q1_".$tahunperiode;//edit1
		// $transaksi_pa_edit2="transaksi_pa_edit2_q1_".$tahunperiode;//edit2
		// $transaksi_pa_detail="transaksi_pa_detail_q1_".$tahunperiode;
		// $tugas_managerial="tugas_managerial_q1_".$tahunperiode;
		// $quartal_periode="Q1-2020";
		// $tabel_sp="sp_2020";
		// $karyawan_promosi = "karyawan_promosi_".$tahunperiode;
	// }
	// else if($tahunproses=='2021' || $tahunproses=='') 
	// {
		// $tahunperiode='2021';
		// $karyawan="karyawan_".$tahunperiode;
		// $transaksi_pa="transaksi_pa_q1_".$tahunperiode;//asli
		// $transaksi_pa_awal="transaksi_pa_awal_q1_".$tahunperiode;//awal
		// $transaksi_pa_edit1="transaksi_pa_edit1_q1_".$tahunperiode;//edit1
		// $transaksi_pa_edit2="transaksi_pa_edit2_q1_".$tahunperiode;//edit2
		// $transaksi_pa_detail="transaksi_pa_detail_q1_".$tahunperiode;
		// $tugas_managerial="tugas_managerial_q1_".$tahunperiode;
		// $quartal_periode=$tahunperiode;
		// $tabel_sp="sp_".$tahunperiode;
		// $karyawan_promosi = "karyawan_promosi_".$tahunperiode;
	// }
// }

?>